<?php
// include('database.inc.php');
// $msg="";
if(isset($_POST['name']) && isset($_POST['email']) && isset($_POST['number']) && isset($_POST['message'])){
	$name=($_POST['name']);
	$email=($_POST['email']);
	$number=($_POST['number']);
	$message=($_POST['message']);
	
	// mysqli_query($con,"insert into contact_us(name,email,mobile,comment) values('$name','$email','$mobile','$comment')");
	// $msg="Thank You for Reaching Out!";
	
	$html="<table><tr><td>name</td><td>$name</td></tr><tr><td>email</td><td>$email</td></tr><tr><td>number</td><td>$number</td></tr><tr><td>message</td><td>$message</td></tr></table>";
	
	include('smtp/PHPMailerAutoload.php');
	$mail=new PHPMailer(true);
	$mail->isSMTP();
	$mail->Host="smtp.gmail.com";
	$mail->Port=587;
	$mail->SMTPSecure="tsl";
	$mail->SMTPAuth=true;
	$mail->Username="raghavnandini9@gmail.com";
	$mail->Password="nocm jvau vewj wcqc";
	$mail->SetFrom("raghavnandini9@gmail.com");
	$mail->addAddress("raghavnandini9@gmail.com");
	$mail->IsHTML(true);
	$mail->Subject="New Contact Us";
	$mail->Body=$html;
	$mail->SMTPOptions=array('ssl'=>array(
		'verify_peer'=>false,
		'verify_peer_name'=>false,
		'allow_self_signed'=>false
	));
	if($mail->send()){
		echo "Thank you";
	}else{
		echo "Error occur";
	}
}
?>